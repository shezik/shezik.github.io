#include <fstream>
#include <iostream>
#include <string>
#include <filesystem>

using namespace std;

int main(int argc, char **argv) {
    cout << "Cisco Packet Tracer 8.2.1.118 No Login Patch" << endl \
         << "For PacketTracer.exe with CRC32 of f7f01f91" << endl \
         << endl;

    if (argc != 2) {
        cout << "Usage:" << endl \
             << "\tpatch.exe <Path-To-PacketTracer.exe>" << endl;
        return 1;
    }

    string sourcePath(argv[1]);
    ifstream sourceRead(sourcePath, ifstream::binary);
    if (sourceRead.fail()) {
        cout << "Failed to open " << sourcePath << "!" << endl;
        return 1;
    }
    uint8_t checksumBuf[4];
    uint8_t expectedChecksum[] = {0x60, 0xB2, 0x1D, 0x05};
    sourceRead.seekg(0x0188);
    sourceRead.read((char *) checksumBuf, 4);
    sourceRead.close();
    if (memcmp(checksumBuf, expectedChecksum, 4)) {
        cout << "Unexpected PE CheckSum, version mismatch?" << endl;
        return 1;
    }

    string backupPath(sourcePath); backupPath.append(".bak");
    if (filesystem::exists(backupPath)) {
        cout << "Backup already exists at " << backupPath << "!" << endl;
        return 1;
    }
    error_code renameResult;
    filesystem::rename(sourcePath, backupPath, renameResult);
    if (renameResult) {
        cout << "Failed to create backup at " << backupPath << "!" << endl;
        return 1;
    }
    
    ofstream sourceWrite(sourcePath, ofstream::binary | ofstream::trunc);
    if (sourceWrite.fail()) {
        cout << "Failed to create " << sourcePath << "!" << endl \
             << "You can restore from the backup file manually at " << backupPath << "." << endl;
        return 1;
    }
    ifstream backup(backupPath, ifstream::binary);
    if (backup.fail()) {
        cout << "Failed to open " << backupPath << "!" << endl \
             << "You can restore from the backup file manually at " << backupPath << "." << endl;
        return 1;
    }
    const unsigned int bufferSize = 1024 * 1024;
    uint8_t buffer[bufferSize];
    unsigned int targetSize = 0x051D6000;  // Excluding code signing certificate
    while (targetSize) {
        unsigned int bytesToRead = min(targetSize, bufferSize);
        backup.read((char *) buffer, bytesToRead);

        unsigned int bytesRead = backup.gcount();
        if (!bytesRead)
            break;
        sourceWrite.write((char *) buffer, bytesRead);
        targetSize -= bytesRead;
    }
    backup.close();

    uint8_t patchedChecksum[] = {0x46, 0x9E};
    sourceWrite.seekp(0x0188);
    sourceWrite.write((char *) patchedChecksum, 2);

    uint8_t patchedCertAddrAndSize[] = {0x00, 0x00, 0x00, 0x00, 0x00};
    sourceWrite.seekp(0x01D9);
    sourceWrite.write((char *) patchedCertAddrAndSize, 5);

    uint8_t patchedAssembly[] = {0xE9, 0x89, 0x0D, 0x00, 0x00, 0x90};
    sourceWrite.seekp(0x02F6BC20);
    sourceWrite.write((char *) patchedAssembly, 6);

    sourceWrite.close();
    return 0;
}
